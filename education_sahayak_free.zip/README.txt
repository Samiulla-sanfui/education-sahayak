শিক্ষা সহায়ক — Free Static Version

এই সংস্করণটি HTML/CSS/JavaScript ভিত্তিক। PHP/MySQL বা আলাদা hosting server প্রয়োজন নেই।
GitHub Pages-এর মতো static hosting-এ চালানো যাবে।

GitHub Pages-এ প্রকাশের সংক্ষিপ্ত ধাপ:
1. GitHub-এ account খুলুন/লগইন করুন।
2. New repository তৈরি করুন, যেমন: education-sahayak
3. index.html ফাইলটি repository-তে upload করুন।
4. Settings → Pages-এ যান।
5. Source হিসেবে Deploy from a branch নির্বাচন করুন।
6. Branch: main এবং folder: / (root) নির্বাচন করে Save করুন।
7. কিছু সময় পরে Visit site থেকে ওয়েবসাইট খুলুন।

কনটেন্ট বদলাতে:
index.html-এর ভিতরের `const data = [...]` অংশে Notes, Question/Answer, MCQ এবং PDF link যোগ/পরিবর্তন করুন।

গুরুত্বপূর্ণ:
- এই version-এ real admin login/database নেই।
- PDF ফাইল সরাসরি upload করার জন্য backend প্রয়োজন।
- পরে PHP + MySQL hosting নিলে পূর্ণ Admin Panel version ব্যবহার করা যাবে।
